[![Open in Codeanywhere](https://codeanywhere.com/img/open-in-codeanywhere-btn.svg)](https://app.codeanywhere.com/#https://github.com/Codeanywhere-Templates/spring-boot)

This is a template project for Spring Boot applications in [Codeanywhere](https://codeanywhere.com/). [Try it out](https://app.codeanywhere.com/#https://github.com/Codeanywhere-Templates/spring-boot)

### Running the project

Open the terminal and run:
```sh
cd test-project
mvn spring-boot:run
```
Or just press the *Run Code* button found in the top right of the editor panel.
### Want to contribute?

Feel free to [open a PR](https://github.com/Codeanywhere-Templates/spring-boot) with any suggestions for this test project 😃 
