package com.codeanywhere.springboot_template;

import java.util.Map;

import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.WriteResult;
import com.google.firebase.cloud.FirestoreClient;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @PostMapping("/signup")
    public ResponseEntity<String> signup(@RequestBody Map<String, String> body) {
        String email = body.get("email");
        String password = body.get("password"); // CAUTION: store securely!

        Firestore db = FirestoreClient.getFirestore();

        Map<String, Object> docData = new HashMap<>();
        docData.put("email", email);
        docData.put("password", password);  // avoid plaintext in real app

        try {
            ApiFuture<WriteResult> future = db.collection("users").document().set(docData);
            WriteResult result = future.get(); // blocking wait for completion

            return ResponseEntity.ok("User saved at: " + result.getUpdateTime());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error saving user");
        }
    }
}
