package com.codeanywhere.springboot_template;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, String> {
    // email is the primary key (String)
}
