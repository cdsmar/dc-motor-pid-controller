package com.codeanywhere.springboot_template;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
